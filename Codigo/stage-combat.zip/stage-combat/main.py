import pygame, sys
from pygame.locals import *
import os
from time import sleep
import random

pygame.init()


ventana = pygame.display.set_mode((1900, 1000))

pygame.display.set_caption("Stage Combat")

clock = pygame.time.Clock()


menuBackground = pygame.image.load("images/MenuLineArt2.jpg").convert_alpha()

jugarBoton = pygame.image.load("images/Jugar.png").convert_alpha()
jugarBoton_rect = jugarBoton.get_rect(topleft = (350,325))

opcionesBoton = pygame.image.load("images/Opciones.png").convert_alpha()
opcionesBoton_rect = opcionesBoton.get_rect(topleft = (600,325))

jugarHover = pygame.image.load("images/JugarHover.png").convert_alpha()
opcionesHover = pygame.image.load("images/OpcionesHover.png").convert_alpha()



color = (10, 25, 80)
color2 = (0, 0 ,0)

def mainMenuScreen():

    while True:
        for evento in pygame.event.get():
            if evento.type == QUIT:
                pygame.quit()
                sys.exit()

        ventana.blit(menuBackground, (0,0))
        ventana.blit(jugarBoton, jugarBoton_rect)

        mouse_pos = pygame.mouse.get_pos()

        if jugarBoton_rect.collidepoint(mouse_pos):
            print("SISISI")
            jugarBoton = pygame.image.load("images/JugarHover.png").convert_alpha()
        else:
            jugarBoton = pygame.image.load("images/Jugar.png").convert_alpha()

        pygame.display.update()
        clock.tick(60)

def optionScreen():
    pass


def characterSelectMenu():
    pass


def backgroundSelectMenu():
    pass


def combatScreen():
    pass