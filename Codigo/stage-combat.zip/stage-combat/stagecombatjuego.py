import os
from time import sleep
import random
import sqlite3
import pygame, sys




# -------------------------------------------------------------------------
# --------------------------------- Clases --------------------------------
# -------------------------------------------------------------------------



# ------------------------------- Jugador ------------------------------


class jugador:
  
  cantidadMuertos = 0
  otroPlayer = None # Jugador oponente
  def __init__(self, numJugador, pantallaDeVictoria, icono):
    self.numPlayer = numJugador
    self.personajesDeJugador = None

    self.pantallaDeVictoria1 = pygame.transform.scale(pantallaDeVictoria, (776, 400))

    self.iconoTransformado = pygame.transform.scale(icono, (200, 150))



# ------------------------------- Character ------------------------------


class character:
    estado = None
    duraEstado = 0
    muerto = False
    oneMore = 0
    pasado = False
    inmovil = False
    bufo = []
    duraBufo = []

    def __init__(
            self, 
            nom, 
            hp, sp, 
            atq, crit, defe, 
            fraseAtq, 
            skillOne, skillTwo, skillThree, 
            botonSeleccion, botonSeleccionHover,
            botonSeleccionUbicacion, botonHoverUbicacion,
            imageSize, imageHoverSize):
        
        self.nombre = nom
        self.vidaMaxima = hp
        self.vida = hp
        self.estamina = sp

        self.fraseAtaque = fraseAtq

        # LAS STATS DE BASE DE USAN PARA RESETEARLAS DESPUES DE QUE SE ACABE UN BUFO
        self.ataqueBase = atq
        self.criticoBase = crit
        self.defensaBase = defe

        self.ataque = atq
        self.critico = crit
        self.defensa = defe

        self.skillOne = skillOne
        self.skillTwo = skillTwo
        self.skillThree = skillThree

        # --- Imagenes ---

        self.botonSeleccion1 = pygame.transform.scale(botonSeleccion, (90, 90))
        self.botonSeleccionHover1 = pygame.transform.scale(botonSeleccionHover, (215, 275))
        self.botonSeleccion_rect = self.botonSeleccion1.get_rect(topleft = botonSeleccionUbicacion)

        self.botonSeleccionUbicacion = botonSeleccionUbicacion
        self.botonHoverUbicacion = botonHoverUbicacion

        charScreen.personajesSinSerelegidos.append(self)

    def seleccionCadaPersonaje(self, mouse_pos, jugadorSinPersonajes, objetoPantallaSeleccion):

        
        ventana.blit(self.botonSeleccion1, self.botonSeleccionUbicacion)                

        if self.botonSeleccion_rect.collidepoint(mouse_pos):

            ventana.blit(self.botonSeleccionHover1, self.botonHoverUbicacion)

            draw_text(self.nombre, text_font, TEXT_COL, 290, 575)
            
            if event.type == pygame.MOUSEBUTTONUP:

                jugadorSinPersonajes.personajesDeJugador = self
                
                objetoPantallaSeleccion.puestoEnElEquipo += 1

                if objetoPantallaSeleccion.puestoEnElEquipo > 1:
                    objetoPantallaSeleccion.jugadorActual = jugadorDos
                    objetoPantallaSeleccion.puestoEnElEquipo = 1

                objetoPantallaSeleccion.personajesSinSerelegidos.remove(self)
                
                print(jugadorSinPersonajes.personajesDeJugador)
                

        else:
            jugarBoton1


# --------------------------------- Habilidad --------------------------------


class habilidad:
  def __init__(self, tipo, nombre, costeSP, efectoExtra, descripcion, textoAlUsarse):
    
    self.tipo = tipo
    self.nombre = nombre
    self.costeSP = costeSP
    
    self.extra = efectoExtra # EL EFECTO EXTRA TIENE DISTINTOS USOS DEPENDIENDO DE CADA TIPO DE HABILIDAD
    
    self.descripcion = descripcion
    self.textoEjecucion = textoAlUsarse



# --------------------------------- pantallaPersonajes --------------------------------


class pantallaPersonajes:

    
    personajesSinSerelegidos = []
    puestoEnElEquipo = 1
    jugadorActual = None

    def cadaSeleccionado(self, jugador, numPersonaje, position):
        if jugador.personajesDeJugador != None:
                ventana.blit(jugador.personajesDeJugador.botonSeleccion1, position)

    def mainPantalla(self):
        
        global pantallaActual
        
        ventana.blit(fondoPersonajes1, (0,0))        
        ventana.blit(volverBoton1, (30, 20))

        


        self.cadaSeleccionado(jugadorUno, 1, (200, 127))
        self.cadaSeleccionado(jugadorDos, 1, (770, 127))


        if len(self.personajesSinSerelegidos) > 1:
            ventana.blit(jugadorUno.iconoTransformado, (545, 50))
            self.jugadorActual = jugadorUno
        else:
            ventana.blit(jugadorDos.iconoTransformado, (545, 50))
            self.jugadorActual = jugadorDos

        if len(self.personajesSinSerelegidos) <= 0:
            pantallaActual = "escenario"
        
        mouse_pos = pygame.mouse.get_pos()

        # Botón volver a atrás

        if volverBoton_rect.collidepoint(mouse_pos):

            ventana.blit(volverHover1, (10, 0))

            if event.type == pygame.MOUSEBUTTONUP:
                pantallaActual = "principal"
                resetVariables()

        for personajeNoElegido in self.personajesSinSerelegidos:
            personajeNoElegido.seleccionCadaPersonaje(mouse_pos, self.jugadorActual, self)

        

# --------------------------------- pantallaCombate --------------------------------


class pantallaCombate:
    
    def __init__(self):

        self.textoEnPantalla = "Inicio del juego"

        chance = [0, 1]

        if random.choice(chance) == 0:
            self.jugadorEnAccion = jugadorUno
            self.oponenteActual = jugadorDos
        else:
            self.jugadorEnAccion = jugadorDos
            self.oponenteActual = jugadorUno

        
        self.personajeEnAccion = 1
        self.ganador = None

        
    def cambioAccion(self):
        self.jugadorEnAccion = self.oponenteActual
        if self.jugadorEnAccion == jugadorUno:
            self.oponenteActual = jugadorDos
        else:
            self.oponenteActual = jugadorUno

    def huir(self):
        escape = [0, 1]
        if random.choice(escape) == 0:
            self.ganador = self.jugadorEnAccion
            self.textoEnPantalla = "Has logrado huir."
        else:
            self.textoEnPantalla = "No has logrado huir."
        

    def atacar(self):
        if self.jugadorEnAccion.personajesDeJugador.ataque <= self.oponenteActual.personajesDeJugador.defensa:
            dañoARealizar = 1
        else:
            dañoARealizar = self.jugadorEnAccion.personajesDeJugador.ataque - self.oponenteActual.personajesDeJugador.defensa

        if random.choice(self.jugadorEnAccion.personajesDeJugador.critico) == 0:
            self.textoEnPantalla = "Has fallado el ataque."
            dañoARealizar = 0

        elif random.choice(self.jugadorEnAccion.personajesDeJugador.critico) == 2:
            dañoARealizar *= 2
            self.textoEnPantalla = "¡Crítico! Has quitado {0} HP a {1}".format(
                dañoARealizar, 
                self.oponenteActual.personajesDeJugador.nombre)

        else:
            self.textoEnPantalla = "{0} ha quitado {1} HP a {2}".format(
                self.jugadorEnAccion.personajesDeJugador.nombre, 
                dañoARealizar, 
                self.oponenteActual.personajesDeJugador.nombre)
            
        if self.oponenteActual.personajesDeJugador.vida - dañoARealizar < 0:
            self.oponenteActual.personajesDeJugador.vida = 0
        else:
            self.oponenteActual.personajesDeJugador.vida -= dañoARealizar
        
        self.cambioAccion()

    def comprobarGanar(self):
        if jugadorUno.personajesDeJugador.vida <= 0:
            jugadorUno.personajesDeJugador.muerto = True
            self.ganador = jugadorDos

            self.textoEnPantalla = "{0} ha muerto.".format(jugadorUno.personajesDeJugador.nombre)

        elif jugadorDos.personajesDeJugador.vida <= 0:
            jugadorDos.personajesDeJugador.muerto = True
            self.ganador = jugadorUno

            self.textoEnPantalla = "{0} ha muerto.".format(jugadorDos.personajesDeJugador.nombre)


    def barravida(self, jugador, positionX):
        longitudBarra = (158 * jugador.personajesDeJugador.vida) / 100

        barraMovibleA = pygame.transform.scale(default, (longitudBarra, 30))
        ventana.blit(barraMovibleA, (positionX, 35))

    def mainPantalla(self):

        global pantallaActual

        # Parte exclusivamente visual de la pantalla
        # Podés pasar la parte visual a otra función que usar para las animaciones

        self.comprobarGanar()

        ventana.blit(escenarioCombate, (0,0))
        ventana.blit(fondoAcciones1, (0,420))

        ventana.blit(atacarBoton1, (60, 490))
        ventana.blit(huirBoton1, (60, 570))

        draw_text(self.textoEnPantalla, text_font, TEXT_COL, 400, 500)

        # Personajes
        ventana.blit(jugadorUno.personajesDeJugador.botonSeleccionHover1, (250, 100))
        ventana.blit(jugadorDos.personajesDeJugador.botonSeleccionHover1, (800, 100))



        # --- Barra de vida ---

        # -- Marco barra de vida --
        ventana.blit(barraVida1, (240, 20))
        ventana.blit(barraVida1, (780, 20))

        # -- La barra en sí --

        self.barravida(jugadorUno, 295)
        self.barravida(jugadorDos, 835)

        # Número barra de vida
        draw_text(str(jugadorUno.personajesDeJugador.vida), text_font, TEXT_COL, 300, 33)
        draw_text(str(jugadorDos.personajesDeJugador.vida), text_font, TEXT_COL, 840, 33)



        # Icono jugador
        ventana.blit(self.jugadorEnAccion.iconoTransformado, (980, 492))

        
        # Parte funcional de la pantalla (botones incluidos)
        mouse_pos = pygame.mouse.get_pos()
        if self.ganador == None:

            

            if atacarBoton_rect.collidepoint(mouse_pos):

                ventana.blit(atacarHover1, (58, 488))

                if event.type == pygame.MOUSEBUTTONUP:
                    self.atacar()
                    #draw_text("El botón funciona.", text_font, TEXT_COL, 500, 500)

            if huirBoton_rect.collidepoint(mouse_pos):

                ventana.blit(huirHover1, (58, 568))

                if event.type == pygame.MOUSEBUTTONUP:

                    self.huir()

        else:
            draw_text("¡{0} ha ganado!".format(self.ganador.personajesDeJugador.nombre), 
                      text_font, 
                      TEXT_COL, 
                      400, 570)
            ventana.blit(self.ganador.pantallaDeVictoria1, (250, 20))

            ventana.blit(jugarBoton1, jugarBoton_rect2)

            if jugarBoton_rect2.collidepoint(mouse_pos):

                ventana.blit(jugarHover2, jugarBoton_rect2)

                if event.type == pygame.MOUSEBUTTONUP:
                    pantallaActual = "principal"





###################
## Inicio sqlite ##
###################

conexion=sqlite3.connect("bd/bdstagecombat.db")


# Fondo menu principal

background=conexion.execute("SELECT imagen FROM infoBackground WHERE idbackground=1")
for fila in background:
     fondobd=fila
     fondonormal= ''.join(fondobd)
print(fondonormal)

###################
## Inicio pygame ##
###################

pygame.init()

clock = pygame.time.Clock()

size = 1280, 720

ventana = pygame.display.set_mode(size)

pygame.display.set_caption("StageCombat")


# -------------------------------------------------------------------------
# --------------------------- Variables globales --------------------------
# -------------------------------------------------------------------------

pantallaActual = "principal"

frasesPuszko = [
  "Ayyy...",
  "Re puto.",
  "Qué puto.",
  "Nashe..."
]

#define fonts
text_font = pygame.font.SysFont("Arial", 30)

#define colours
TEXT_COL = (0, 0, 0)


escenarioCombate = None



# -------------------------------------------------------------------------
# ------------------------------- Imagenes -------------------------------
# -------------------------------------------------------------------------

# Background en blanco

fondoDefault = pygame.image.load("images/Default.png").convert_alpha()
fondoDefault1 = pygame.transform.scale(fondoDefault, (1280, 720))


# --- Menú principal ---

# Background

fondo = pygame.image.load(fondonormal).convert_alpha()
fondo1 = pygame.transform.scale(fondo, (1280, 720))
fondoOscuro = pygame.image.load("images/menuprincipaloscuro.jpg").convert_alpha()
fondo1Oscuro = pygame.transform.scale(fondoOscuro, (1280, 720))

# Boton Jugar

jugarBoton = pygame.image.load("images/Jugar.png").convert_alpha()
jugarBoton1 = pygame.transform.scale(jugarBoton, (295, 100))
jugarBoton_rect = jugarBoton1.get_rect(topleft = (290,306))
jugarBoton_rect2 = jugarBoton1.get_rect(topleft = (500, 300))
jugarHover = pygame.image.load("images/JugarHover.png").convert_alpha()
jugarHover1 = pygame.transform.scale(jugarHover, (470, 270))
jugarHover2 = pygame.transform.scale(jugarBoton, (305, 110))

# Boton Opciones

opcionesBoton = pygame.image.load("images/Opciones.png").convert_alpha()
opcionesBoton1 = pygame.transform.scale(opcionesBoton, (295, 100))
opcionesBoton_rect = opcionesBoton1.get_rect(topleft = (705,307))
opcionesHover = pygame.image.load("images/OpcionesHover.png").convert_alpha()
opcionesHover1 = pygame.transform.scale(opcionesHover, (470, 270))



# --- Menú seleccionPersonajes ---

# botonVolver

volverBoton = pygame.image.load("images/botonVolver.png").convert_alpha()
volverBoton1 = pygame.transform.scale(volverBoton, (150, 150))
volverBoton_rect = volverBoton1.get_rect(topleft = (30, 30))
volverHover1 = pygame.transform.scale(volverBoton, (200, 200))

# Background

fondoPersonajes = pygame.image.load("images/Fondo.jpg").convert_alpha()
fondoPersonajes1 = pygame.transform.scale(fondoPersonajes, (1280, 720))

# - Icono jugadores -

# Icono jugador uno

iconoj1Base = pygame.image.load("images/J1.png")

# Icono jugador dos

iconoj2Base = pygame.image.load("images/J2.png")

# Botón personaje falso

luismiBoton = pygame.image.load("images/luismi.png").convert_alpha()
luismiBoton1 = pygame.transform.scale(luismiBoton, (400, 400))
luismisBoton_rect = luismiBoton1.get_rect(topleft = (550,500))
luismiHover = pygame.image.load("images/luismi.png").convert_alpha()
luismiHover1 = pygame.transform.scale(luismiHover, (400, 400))

# Botón nekoarc

nekoarcBoton = pygame.image.load("images/NekoArcIco.png").convert_alpha()
nekoarcBoton1 = pygame.transform.scale(nekoarcBoton, (35, 35))
nekoarcBoton_rect = luismiBoton1.get_rect(topleft = (550,500))
nekoarcHover = pygame.image.load("images/Neko Arc.png").convert_alpha()
nekoarcHover1 = pygame.transform.scale(nekoarcHover, (35, 35))


# Botón nekoarc

nekoarcChaosBoton = pygame.image.load("images/NecoArcChaosIco.png").convert_alpha()
nekoarcChaosHover = pygame.image.load("images/Neco Arc Chaos.png").convert_alpha()

# Botón personaje 3



# Botón personaje 4



# Botón personaje 5



# Botón personaje 6



# Botón personaje 7



# Botón personaje 8




# --- Menú seleccionEscenarios ---


# Background 

fondoEscenarios = pygame.image.load("images/background.png").convert_alpha()
fondoEscenarios1 = pygame.transform.scale(fondoEscenarios, (1280, 720))

# -- Botones --

# Boton sample

sampleBoton = pygame.image.load("images/escenarioSample.png").convert_alpha()
sampleBoton1 = pygame.transform.scale(sampleBoton, (218, 400))
sampleBoton_rect = sampleBoton1.get_rect(topleft = (270, 215))
sampleHover = pygame.image.load("images/escenarioSample.png").convert_alpha()
sampleHover1 = pygame.transform.scale(sampleHover, (228, 410))

# Boton mercado
mercadoBoton = pygame.image.load("images/seleccionMercado.png").convert_alpha()
mercadoBoton1 = pygame.transform.scale(mercadoBoton, (218, 400))
mercadoBoton_rect = sampleBoton1.get_rect(topleft = (270, 215))
mercadoHover = pygame.image.load("images/seleccionMercado.png").convert_alpha()
mercadoHover1 = pygame.transform.scale(mercadoHover, (228, 410))

# Boton 
coliseoBoton = pygame.image.load("images/seleccionColiseo.png").convert_alpha()
coliseoBoton1 = pygame.transform.scale(coliseoBoton, (218, 400))
coliseoBoton_rect = sampleBoton1.get_rect(topleft = (793, 215))
coliseoHover = pygame.image.load("images/seleccionColiseo.png").convert_alpha()
coliseoHover1 = pygame.transform.scale(coliseoHover, (228, 410))

# Boton tren
trenBoton = pygame.image.load("images/seleccionTren.png").convert_alpha()
trenBoton1 = pygame.transform.scale(trenBoton, (218, 400))
trenBoton_rect = sampleBoton1.get_rect(topleft = (533, 215))
trenHover = pygame.image.load("images/seleccionTren.png").convert_alpha()
trenHover1 = pygame.transform.scale(trenHover, (228, 410))

# -- Fondos de combate --

# Fondo sample
fondoSample0 = pygame.image.load("images/Fondo.jpg").convert_alpha()
fondoMercado0 = pygame.image.load("images/fondoMercado.png").convert_alpha()
fondoColiseo0 = pygame.image.load("images/fondoColiseo.png").convert_alpha()
fondoTren0 = pygame.image.load("images/fondoTren.png").convert_alpha()

fondoMercado = pygame.transform.scale(fondoMercado0, (1280, 720))
fondoColiseo = pygame.transform.scale(fondoColiseo0, (1280, 720))
fondoTren = pygame.transform.scale(fondoTren0, (1280, 720))

# --- Menú opciones ---



# --- Pantalla combate ---

# - Barra de vida -

# Icono barra de vida
barraVida = pygame.image.load("images/BarraVida.png").convert_alpha()
barraVida1 = pygame.transform.scale(barraVida, (240, 60))



# -- Menu acciones --

# Fondo menu
fondoAcciones = pygame.image.load("images/seleccionHab.png").convert_alpha()
fondoAcciones1 = pygame.transform.scale(fondoAcciones, (1275, 300))

# Botón atacar

atacarBoton = pygame.image.load("images/Boton Atacar.png").convert_alpha()
atacarBoton1 = pygame.transform.scale(atacarBoton, (260, 80))
atacarBoton_rect = atacarBoton1.get_rect(topleft = (60, 490))
atacarHover = pygame.image.load("images/Boton Atacar.png").convert_alpha()
atacarHover1 = pygame.transform.scale(atacarHover, (265, 85))

# Botón huir

huirBoton = pygame.image.load("images/Boton Huir.png").convert_alpha()
huirBoton1 = pygame.transform.scale(huirBoton, (260, 80))
huirBoton_rect = huirBoton1.get_rect(topleft = (60, 570))
huirHover = pygame.image.load("images/Boton Huir.png").convert_alpha()
huirHover1 = pygame.transform.scale(huirHover, (265, 85))

# -- Victoria de jugador --

# Jugador Uno
victoriaUno = pygame.image.load("images/victoriaJ1.png").convert_alpha()

# Jugador Dos
victoriaDos = pygame.image.load("images/victoriaJ2.png").convert_alpha()








default = pygame.image.load("images/Default.png").convert_alpha()
default1 = pygame.transform.scale(default, (1280, 720))



# -------------------------------------------------------------------------
# -------------------------------- Objetos --------------------------------
# -------------------------------------------------------------------------

jugadorUno = jugador(1, victoriaUno, iconoj1Base)
jugadorDos = jugador(2, victoriaDos, iconoj2Base)

jugadorUno.otroPlayer = jugadorDos
jugadorDos.otroPlayer = jugadorUno

charScreen = pantallaPersonajes()
combatScreen = pantallaCombate()

# --- Habilidades ---

puñetazo = habilidad("dps", "Puñetazo", 5, "congelado", "El usuario da un puñetazo especialmente fuerte contra objetivos congelados.", "Diste un puñetazo al objetivo.")

santaCura = habilidad("curar", "Santa cura", 10, "mucho", "El usuario utiliza el poder divino para curar a un aliado.", "Usaste el poder divino para curar a tu aliado.")

botellazo = habilidad("dps", "Botellazo", 5, "quemado", "El usuario lanza una botella con alcohol al oponente.", "Le lanzaste una botella al oponente.")

cocinaAmorosa = habilidad("dps", "Cocina amorosa", 5, "enamorado", "el usuario cocina un pastel que hace daño al enemigo, especialmente si está enamorado.", "Le diste un pastel tan dulce al enemigo que le hiciste daño.")

simpeo = habilidad("control", "Simpeo", 10, "enamorado", "El usuario utiliza palabras dulces para enamorar al objetivo.", "Le dijiste palabras dulces al oponente para enamorarlo.")

# --- Personajes ---

#luismi = character(
#    "Luismi", 
#    200, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, 
#    frasesPuszko, 
#    puñetazo, 
#    santaCura, 
#    botellazo,
#    luismiBoton,
#    luismiHover,
#    (633, 476), (240, 245),
#    (35, 35), (35, 35))

nekoArc = character(
    "NekoArc", 
    100, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, 
    frasesPuszko, 
    puñetazo, 
    santaCura, 
    botellazo,
    nekoarcBoton, nekoarcHover,
    (522,475), (240, 245),
    (400, 400), (300, 425))

luismi = character(
    "LuisMi", 
    100, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, 
    frasesPuszko, 
    puñetazo, 
    santaCura, 
    botellazo,
    nekoarcChaosBoton, nekoarcChaosHover,
    (633, 476), (240, 245),
    (35, 35), (35, 35))



# -------------------------------------------------------------------------
# --------------------------- Funciones globales --------------------------
# -------------------------------------------------------------------------


def draw_text(text, font, text_col, x, y):
  img = font.render(text, True, text_col)
  ventana.blit(img, (x, y))

def menu():
    global pantallaActual
    if pantallaActual == "principal":
        menuInicial()

    elif pantallaActual == "personajes":
        charScreen.mainPantalla()

    elif pantallaActual == "escenario":
        menuEscenario()

    elif pantallaActual == "combate":
        combatScreen.mainPantalla()

    elif pantallaActual == "opciones":
        menuOpciones()

def resetVariables():
    
    #print("resetando variables")
    
    charScreen.personajesSinSerelegidos = [nekoArc, luismi]
    charScreen.puestoEnElEquipo = 1
    charScreen.jugadorActual = None

    combatScreen.ganador = None

    for personajeUsado in charScreen.personajesSinSerelegidos:
        personajeUsado.vida = personajeUsado.vidaMaxima

    jugadorUno.personajesDeJugador = None
    jugadorDos.personajesDeJugador = None
    
    


def menuInicial():
    global pantallaActual

    ventana.blit(fondo1, (0,0))
    ventana.blit(jugarBoton1, jugarBoton_rect)
    ventana.blit(opcionesBoton1, opcionesBoton_rect)

    resetVariables()

    mouse_pos = pygame.mouse.get_pos()
    
    if jugarBoton_rect.collidepoint(mouse_pos):
        ventana.blit(fondo1Oscuro, (0,0))
        ventana.blit(jugarHover1, (200,240))
        if event.type == pygame.MOUSEBUTTONUP:
            pantallaActual = "personajes"
    else:
        jugarBoton1

    if opcionesBoton_rect.collidepoint(mouse_pos):
        ventana.blit(fondo1Oscuro, (0,0))
        ventana.blit(opcionesHover1, (600,240))
        if event.type == pygame.MOUSEBUTTONUP:
            pantallaActual = "opciones"
    else:
        opcionesBoton1
     

def menuEscenario():

    global pantallaActual, escenarioCombate

    ventana.blit(fondoEscenarios1, (0,0))

    ventana.blit(mercadoBoton1, (270, 215))
    ventana.blit(trenBoton1, (533, 215))
    ventana.blit(coliseoBoton1, (793, 215))

    ventana.blit(volverBoton1, (30, 20))

    mouse_pos = pygame.mouse.get_pos()
    
    if mercadoBoton_rect.collidepoint(mouse_pos):
        
        ventana.blit(mercadoHover1, (265, 212))

        if event.type == pygame.MOUSEBUTTONUP:
            escenarioCombate = fondoMercado
            pantallaActual = "combate"
            print(escenarioCombate)

    elif trenBoton_rect.collidepoint(mouse_pos):
        
        ventana.blit(trenHover1, (528, 212))

        if event.type == pygame.MOUSEBUTTONUP:
            escenarioCombate = fondoTren
            pantallaActual = "combate"
            print(escenarioCombate)

    elif coliseoBoton_rect.collidepoint(mouse_pos):
        
        ventana.blit(coliseoHover1, (788, 212))

        if event.type == pygame.MOUSEBUTTONUP:
            escenarioCombate = fondoColiseo
            pantallaActual = "combate"
            print(escenarioCombate)

    elif volverBoton_rect.collidepoint(mouse_pos):

            ventana.blit(volverHover1, (10, 0))

            if event.type == pygame.MOUSEBUTTONUP:
                pantallaActual = "personajes"
                resetVariables()

    

    #if volverBoton_rect.collidepoint(mouse_pos):
#
 #           ventana.blit(volverHover1, (0, 0))

  #          if event.type == pygame.MOUSEBUTTONUP:
   #             pantallaActual = "personajes"





     
def menuOpciones():
    global pantallaActual
    ventana.blit(fondoDefault1, (0,0))
    

   
####################
### Inicio juego ###
####################
    

run=True
while run:

    for event in pygame.event.get():

        if event.type == pygame.QUIT: run = False
        menu()
        pygame.display.update()

    clock.tick(60)




conexion.close

pygame.quit()