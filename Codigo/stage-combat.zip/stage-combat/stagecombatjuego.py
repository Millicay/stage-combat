import os
from time import sleep
import random
import sqlite3
import pygame, sys


# -------------------------------------------------------------------------
# --------------------------- Variables globales --------------------------
# -------------------------------------------------------------------------



frasesPuszko = [
  "Ayyy...",
  "Re puto.",
  "Qué puto.",
  "Nashe..."
]

escenarioCombate = None

# -------------------------------------------------------------------------
# --------------------------------- Clases --------------------------------
# -------------------------------------------------------------------------


class jugador:
  
  cantidadMuertos = 0
  otroPlayer = None # Jugador oponente
  def __init__(self, numJugador):
    self.numPlayer = numJugador
    self.personajesDeJugador = {1: None, 2: None, 3: None, 4: None} # Directorio con los personajes del jugador



class character:
    estado = None
    duraEstado = 0
    muerto = False
    oneMore = 0
    pasado = False
    inmovil = False
    bufo = []
    duraBufo = []

    def __init__(
            self, 
            nom, 
            hp, sp, 
            atq, crit, defe, 
            fraseAtq, 
            skillOne, skillTwo, skillThree, 
            botonSeleccion, botonSeleccionHover,
            botonSeleccionUbicacion, botonHoverUbicacion,
            imageSize, imageHoverSize):
        
        self.nombre = nom
        self.vidaMaxima = hp
        self.vida = hp
        self.estamina = sp

        self.fraseAtaque = fraseAtq

        # LAS STATS DE BASE DE USAN PARA RESETEARLAS DESPUES DE QUE SE ACABE UN BUFO
        self.ataqueBase = atq
        self.criticoBase = crit
        self.defensaBase = defe

        self.ataque = atq
        self.critico = crit
        self.defensa = defe

        self.skillOne = skillOne
        self.skillTwo = skillTwo
        self.skillThree = skillThree

        # --- Imagenes ---

        self.botonSeleccion1 = pygame.transform.scale(botonSeleccion, (90, 90))
        self.botonSeleccionHover1 = pygame.transform.scale(botonSeleccionHover, (215, 275))
        self.botonSeleccion_rect = self.botonSeleccion1.get_rect(topleft = botonSeleccionUbicacion)

        self.botonSeleccionUbicacion = botonSeleccionUbicacion
        self.botonHoverUbicacion = botonHoverUbicacion

        charScreen.personajesSinSerelegidos.append(self)

    def seleccionCadaPersonaje(self, mouse_pos, jugadorSinPersonajes, objetoPantallaSeleccion):

        
        ventana.blit(self.botonSeleccion1, self.botonSeleccionUbicacion)                

        if self.botonSeleccion_rect.collidepoint(mouse_pos):
        

            ventana.blit(self.botonSeleccionHover1, self.botonHoverUbicacion)
            
            if event.type == pygame.MOUSEBUTTONUP:

                jugadorSinPersonajes.personajesDeJugador[objetoPantallaSeleccion.puestoEnElEquipo] = self
                
                objetoPantallaSeleccion.puestoEnElEquipo += 1

                if objetoPantallaSeleccion.puestoEnElEquipo > 1:
                    objetoPantallaSeleccion.jugadorActual = jugadorDos
                    objetoPantallaSeleccion.puestoEnElEquipo = 1

                objetoPantallaSeleccion.personajesSinSerelegidos.remove(self)
                
                print(jugadorSinPersonajes.personajesDeJugador)
                

        else:
            jugarBoton1



class habilidad:
  def __init__(self, tipo, nombre, costeSP, efectoExtra, descripcion, textoAlUsarse):
    
    self.tipo = tipo
    self.nombre = nombre
    self.costeSP = costeSP
    
    self.extra = efectoExtra # EL EFECTO EXTRA TIENE DISTINTOS USOS DEPENDIENDO DE CADA TIPO DE HABILIDAD
    
    self.descripcion = descripcion
    self.textoEjecucion = textoAlUsarse


class pantallaPersonajes:

    personajesSinSerelegidos = []
    puestoEnElEquipo = 1
    jugadorActual = None

    def cadaSeleccionado(self, jugador, numPersonaje, position):
        if jugador.personajesDeJugador[numPersonaje] != None:
                ventana.blit(jugador.personajesDeJugador[numPersonaje].botonSeleccion1, position)

    def mainPantalla(self):
        
        global pantallaActual
        
        ventana.blit(fondoPersonajes1, (0,0))        


        self.cadaSeleccionado(jugadorUno, 1, (200, 127))
        self.cadaSeleccionado(jugadorUno, 2, (260, 127))
        self.cadaSeleccionado(jugadorUno, 3, (400, 127))
        self.cadaSeleccionado(jugadorUno, 4, (500, 127))

        self.cadaSeleccionado(jugadorDos, 1, (770, 127))
        self.cadaSeleccionado(jugadorDos, 2, (900, 127))
        self.cadaSeleccionado(jugadorDos, 3, (1000, 127))
        self.cadaSeleccionado(jugadorDos, 4, (1100, 127))

        if len(self.personajesSinSerelegidos) > 1:
            self.jugadorActual = jugadorUno
        else:

            self.jugadorActual = jugadorDos

        if len(self.personajesSinSerelegidos) <= 0:
            pantallaActual = "escenario"
        
        mouse_pos = pygame.mouse.get_pos()

        

        for personajeNoElegido in self.personajesSinSerelegidos:
            personajeNoElegido.seleccionCadaPersonaje(mouse_pos, self.jugadorActual, self)

        



###################
## Inicio sqlite ##
###################

conexion=sqlite3.connect("bd/bdstagecombat.db")


# Fondo menu principal

background=conexion.execute("SELECT imagen FROM infoBackground WHERE idbackground=1")
for fila in background:
     fondobd=fila
     fondonormal= ''.join(fondobd)
print(fondonormal)

###################
## Inicio pygame ##
###################

pygame.init()

clock = pygame.time.Clock()

size = 1280, 720

ventana = pygame.display.set_mode(size)

pygame.display.set_caption("StageCombat")






# -------------------------------------------------------------------------
# ------------------------------- Imagenes -------------------------------
# -------------------------------------------------------------------------

# Background en blanco

fondoDefault = pygame.image.load("images/Default.png").convert_alpha()
fondoDefault1 = pygame.transform.scale(fondoDefault, (1280, 720))


# --- Menú principal ---

# Background

fondo = pygame.image.load(fondonormal).convert_alpha()
fondo1 = pygame.transform.scale(fondo, (1280, 720))
fondoOscuro = pygame.image.load("images/menuprincipaloscuro.jpg").convert_alpha()
fondo1Oscuro = pygame.transform.scale(fondoOscuro, (1280, 720))

# Boton Jugar

jugarBoton = pygame.image.load("images/Jugar.png").convert_alpha()
jugarBoton1 = pygame.transform.scale(jugarBoton, (295, 100))
jugarBoton_rect = jugarBoton1.get_rect(topleft = (290,306))
jugarHover = pygame.image.load("images/JugarHover.png").convert_alpha()
jugarHover1 = pygame.transform.scale(jugarHover, (470, 270))

# Boton Opciones

opcionesBoton = pygame.image.load("images/Opciones.png").convert_alpha()
opcionesBoton1 = pygame.transform.scale(opcionesBoton, (295, 100))
opcionesBoton_rect = opcionesBoton1.get_rect(topleft = (705,307))
opcionesHover = pygame.image.load("images/OpcionesHover.png").convert_alpha()
opcionesHover1 = pygame.transform.scale(opcionesHover, (470, 270))



# --- Menú seleccionPersonajes ---

# Background

fondoPersonajes = pygame.image.load("images/Fondo.jpg").convert_alpha()
fondoPersonajes1 = pygame.transform.scale(fondoPersonajes, (1280, 720))

# Botón personaje falso

luismiBoton = pygame.image.load("images/luismi.png").convert_alpha()
luismiBoton1 = pygame.transform.scale(luismiBoton, (400, 400))
luismisBoton_rect = luismiBoton1.get_rect(topleft = (550,500))
luismiHover = pygame.image.load("images/luismi.png").convert_alpha()
luismiHover1 = pygame.transform.scale(luismiHover, (400, 400))

# Botón nekoarc

nekoarcBoton = pygame.image.load("images/NekoArcIco.png").convert_alpha()
nekoarcBoton1 = pygame.transform.scale(nekoarcBoton, (35, 35))
nekoarcBoton_rect = luismiBoton1.get_rect(topleft = (550,500))
nekoarcHover = pygame.image.load("images/Neko Arc.png").convert_alpha()
nekoarcHover1 = pygame.transform.scale(nekoarcHover, (35, 35))

# Botón personaje 1



# Botón personaje 2



# Botón personaje 3



# Botón personaje 4



# Botón personaje 5



# Botón personaje 6



# Botón personaje 7



# Botón personaje 8




# --- Menú seleccionEscenarios ---


# Background 

fondoEscenarios = pygame.image.load("images/background.png").convert_alpha()
fondoEscenarios1 = pygame.transform.scale(fondoEscenarios, (1280, 720))

# Boton sample

sampleBoton = pygame.image.load("images/escenarioSample.png").convert_alpha()
sampleBoton1 = pygame.transform.scale(sampleBoton, (218, 400))
sampleBoton_rect = sampleBoton1.get_rect(topleft = (270, 215))
sampleHover = pygame.image.load("images/escenarioSample.png").convert_alpha()
sampleHover1 = pygame.transform.scale(sampleHover, (228, 410))




# --- Menú opciones ---



# --- Pantalla combate ---

# - Fondos de combate -

fondoColiseo = pygame.image.load("images/Fondo.jpg").convert_alpha()




default = pygame.image.load("images/Default.png").convert_alpha()
default1 = pygame.transform.scale(default, (1280, 720))



# -------------------------------------------------------------------------
# -------------------------------- Objetos --------------------------------
# -------------------------------------------------------------------------

jugadorUno = jugador(1)
jugadorDos = jugador(2)

jugadorUno.otroPlayer = jugadorDos
jugadorDos.otroPlayer = jugadorUno

charScreen = pantallaPersonajes()

# --- Habilidades ---

puñetazo = habilidad("dps", "Puñetazo", 5, "congelado", "El usuario da un puñetazo especialmente fuerte contra objetivos congelados.", "Diste un puñetazo al objetivo.")

santaCura = habilidad("curar", "Santa cura", 10, "mucho", "El usuario utiliza el poder divino para curar a un aliado.", "Usaste el poder divino para curar a tu aliado.")

botellazo = habilidad("dps", "Botellazo", 5, "quemado", "El usuario lanza una botella con alcohol al oponente.", "Le lanzaste una botella al oponente.")

cocinaAmorosa = habilidad("dps", "Cocina amorosa", 5, "enamorado", "el usuario cocina un pastel que hace daño al enemigo, especialmente si está enamorado.", "Le diste un pastel tan dulce al enemigo que le hiciste daño.")

simpeo = habilidad("control", "Simpeo", 10, "enamorado", "El usuario utiliza palabras dulces para enamorar al objetivo.", "Le dijiste palabras dulces al oponente para enamorarlo.")

# --- Personajes ---

luismi = character(
    "Luismi", 
    200, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, 
    frasesPuszko, 
    puñetazo, 
    santaCura, 
    botellazo,
    luismiBoton,
    luismiHover,
    (633, 476), (240, 245),
    (35, 35), (35, 35))

nekoArc = character(
    "Neko Arc", 
    200, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, 
    frasesPuszko, 
    puñetazo, 
    santaCura, 
    botellazo,
    nekoarcBoton, nekoarcHover,
    (522,475), (240, 245),
    (400, 400), (300, 425))


####################
### Inicio juego ###
####################

pantallaActual = "principal"

def menu():
    global pantallaActual
    if pantallaActual == "principal":
        menuInicial()

    elif pantallaActual == "personajes":
        charScreen.mainPantalla()

    elif pantallaActual == "escenario":
        menuEscenario()

    elif pantallaActual == "combate":
        menuCombate()

    elif pantallaActual == "opciones":
        menuOpciones()
    

def menuInicial():
    global pantallaActual

    ventana.blit(fondo1, (0,0))
    ventana.blit(jugarBoton1, jugarBoton_rect)
    ventana.blit(opcionesBoton1, opcionesBoton_rect)

    mouse_pos = pygame.mouse.get_pos()
    
    if jugarBoton_rect.collidepoint(mouse_pos):
        ventana.blit(fondo1Oscuro, (0,0))
        ventana.blit(jugarHover1, (200,240))
        if event.type == pygame.MOUSEBUTTONUP:
            pantallaActual = "personajes"
    else:
        jugarBoton1

    if opcionesBoton_rect.collidepoint(mouse_pos):
        ventana.blit(fondo1Oscuro, (0,0))
        ventana.blit(opcionesHover1, (600,240))
        if event.type == pygame.MOUSEBUTTONUP:
            pantallaActual = "opciones"
    else:
        opcionesBoton1
     

def menuEscenario():

    global pantallaActual, escenarioCombate

    ventana.blit(fondoEscenarios1, (0,0))
    ventana.blit(sampleBoton1, (270, 215))

    mouse_pos = pygame.mouse.get_pos()
    
    if sampleBoton_rect.collidepoint(mouse_pos):
        ventana.blit(fondoEscenarios1, (0,0))
        ventana.blit(sampleHover1, (270, 215))

        if event.type == pygame.MOUSEBUTTONUP:
            escenarioCombate = fondoColiseo
            pantallaActual = "combate"
            print(escenarioCombate)




     
def menuCombate():
    global pantallaActual
    ventana.blit(fondoDefault1, (0,0))
    

    mouse_pos = pygame.mouse.get_pos()

     
def menuOpciones():
    global pantallaActual
    ventana.blit(fondoDefault1, (0,0))
    

   
    
    

run=True
while run:

    for event in pygame.event.get():

        if event.type == pygame.QUIT: run = False
        menu()
        pygame.display.update()

    clock.tick(60)




conexion.close

pygame.quit()