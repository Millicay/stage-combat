import os
from time import sleep
import random
import sqlite3
import pygame, sys

###################
## Inicio pygame ##
###################

pygame.init()

clock = pygame.time.Clock()

size = 1920, 1080

ventana = pygame.display.set_mode(size)

pygame.display.set_caption("StageCombat")

fondo = pygame.image.load("img/background.png").convert_alpha()

jugarBoton = pygame.image.load("img/Jugar.png").convert_alpha()
jugarBoton_rect = jugarBoton.get_rect(topleft = (444,464))

opcionesBoton = pygame.image.load("img/Opciones.png").convert_alpha()
opcionesBoton_rect = opcionesBoton.get_rect(topleft = (600,325))

jugarHover = pygame.image.load("img/JugarHover.png").convert_alpha()
opcionesHover = pygame.image.load("img/OpcionesHover.png").convert_alpha()

###################
## Inicio sqlite ##
###################

conexion=sqlite3.connect("bd/bdstagecombat.db")
cursor=conexion.execute("SELECT id_juego,nombre FROM juego")
for fila in cursor:
  print(fila)


####################
### Inicio juego ###
####################

run=True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: run = False

        ventana.blit(fondo, (0,0))
        ventana.blit(jugarBoton, jugarBoton_rect)
        ventana.blit(jugarBoton, opcionesBoton_rect)

        mouse_pos = pygame.mouse.get_pos()

        if jugarBoton_rect.collidepoint(mouse_pos):
            jugarBoton = pygame.image.load("img/JugarHover.png").convert_alpha()
        else:
            jugarBoton = pygame.image.load("img/Jugar.png").convert_alpha()

        if opcionesBoton_rect.collidepoint(mouse_pos):
            opcionesBoton = pygame.image.load("img/JugarHover.png").convert_alpha()
        else:
            opcionesBoton = pygame.image.load("img/Jugar.png").convert_alpha()


        pygame.display.update()
        clock.tick(60)


conexion.close

pygame.quit()