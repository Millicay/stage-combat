import os
from time import sleep
import random

class jugador:
  player = {}
  cantidadMuertos = 0
  otroPlayer = None
  def __init__(self, numJugador):
    self.numPlayer = numJugador



  def huir(self):
    global gameOver
    if random.choice(escape) == 1:
      sleep(1)
      print("")
      print("Has logrado huir. Jugador {0} pierde.".format(self.numPlayer))
      sleep(3)
      gameOver = True
      
    else:
      sleep(1)
      print("No has logrado huir.")
      sleep(1)




  
  def turno(self, pj):
    comprobarPasado()
    #Propósito: Menú con las acciones disponibles de los characteres.
    
    if self.player[pj].inmovil == False:
      printerVidaJugadores()
  
      
      print("Jugador {0}: {1}".format(self.numPlayer, self.player[pj].nombre))
      print("Acciones:")
      print('''
            1. Atacar
            2. Habilidades
            3. Huir
            ''')
      q = int(input("¿Qué desea hacer?: "))
      
      if q == 1:
        self.atacar(pj)
        
      elif q == 2:
        self.habilidades(pj)
        
      elif q == 3:
        self.huir()
        
      else:
        print(q, "no es válido.")
        sleep(1)
    
        os.system('clear')
        self.turno(pj)
  


  
  def encore(self, pj):
    comprobarPasado()
    #Propósito: Menú con las acciones disponibles de los characteres.
    
    if self.player[pj].inmovil == False:
      printerVidaJugadores()
  
      
      print("Jugador {0}: {1}".format(self.numPlayer, self.player[pj].nombre))
      print("Acciones:")
      print('''
            1. Atacar
            2. Habilidades
            3. Huir
            4. Pase
            ''')
      q = int(input("¿Qué desea hacer?: "))
      
      if q == 1:
        self.atacar(pj)
        
      elif q == 2:
        self.habilidades(pj)
        
      elif q == 3:
        self.huir()

      elif q == 4:
        self.player[pj].pasado = True
        objetivoPase = int(input("Seleccione un objetivo [1][2][3][4]: "))
        
        if objetivoPase > 4:
          print("Objetivo no válido.")
          self.encore(pj)
          
        elif self.player[objetivoPase].pasado == True:
          print("No puedes hacer un pase a este objetivo.")
          self.encore(pj)
  
        else:
          self.player[objetivoPase].pasado = True
          self.turno(objetivoPase)
        
      else:
        print(q, "no es válido.")
        sleep(1)
    
        os.system('clear')
        self.turno(pj)











  

  def ataqueCritico(self, objetivo, pj):
  
    
    crit = self.player[pj].ataque * 2
    
    print("")
    sleep(1)
    print("¡Crítico!")
    sleep(1)
    
    if crit < self.otroPlayer.player[objetivo].defensa:
      self.otroPlayer.player[objetivo].vida -= 1
      
    else:
      self.otroPlayer.player[objetivo].vida -= crit - self.otroPlayer.player[objetivo].defensa
  
    if self.otroPlayer.player[objetivo].estado != "stuneado":
      print("")
      print("  * Encore! *")
      sleep(0.5)
      self.player[pj].oneMore += 1
      self.otroPlayer.player[objetivo].estado = "stuneado"
      self.otroPlayer.player[objetivo].duraEstado = 1
      self.encore(pj)



  def ataqueComun(self, objetivo, pj):
    #Propósito:   
    
    if self.player[pj].ataque < self.player[pj].defensa:
      self.otroPlayer.player[objetivo].vida -= 1
      
    else:
      self.otroPlayer.player[objetivo].vida -= self.player[pj].ataque - self.otroPlayer.player[objetivo].defensa
  
      print("")
      print("{0} pierde {1} HP".format(
        self.otroPlayer.player[objetivo].nombre, self.player[pj].ataque - self.otroPlayer.player[objetivo].defensa)
           )
      sleep(0.5)





  
  def atacar(self, pj):
    #Propósito: Determinar a quien y como se ataca.
    
    printerVidaJugadores()
  
    printPersonajeQueAtaca(self.player, pj)

    objetivo = seleccionObjetivo(self.otroPlayer)

    crit = random.choice(self.player[pj].critico)
    
    if crit == 0:
      sleep(1)
      print("")
      print("Golpe fallido")
      sleep(0.5)
      
    elif crit == 1:
      self.ataqueComun(objetivo, pj)
        
    elif crit == 2:
      self.ataqueCritico(objetivo, pj)
  
    else:
      self.ataqueComun(objetivo, pj)
  
    if random.choice(chance) == 2:
      sleep(0.5)
      print("")
      print("{0}: {1}".format(self.player[pj].nombre, random.choice(self.player[pj].fraseAtaque)))
      sleep(1.5)
      
    printerVidaJugadores()

        
  def habilidades(self, pj):
    print('''
            1. {0}
            2. {1}
            3. {2}
            0. Volver
            '''.format(self.player[pj].skillOne.nombre, self.player[pj].skillTwo.nombre, self.player[pj].skillThree.nombre))
    habilidadAUsar = int(input("Habilidad: "))

    if habilidadAUsar != 0:
    
      objetivo = seleccionObjetivo(self.otroPlayer)
  
      if objetivo != 0:
      
        if habilidadAUsar == 1:
          self.player[pj].skillOne.usarHabilidad(self.player, self.otroPlayer, pj, objetivo, self)
    
        if habilidadAUsar == 2:
          self.player[pj].skillTwo.usarHabilidad(self.player, self.otroPlayer, pj, objetivo, self)
    
        if habilidadAUsar == 3:
          self.player[pj].skillThree.usarHabilidad(self.player, self.otroPlayer, pj, objetivo, self)
          
  
      else:
        self.habilidades(pj)
        
    else:
      self.turno(pj)
  










jugadorUno = jugador(1)
jugadorDos = jugador(2)

jugadorUno.otroPlayer = jugadorDos
jugadorDos.otroPlayer = jugadorUno
  

class accionPersonaje:
  def __init__(self, player, pj, otroPlayer):
    self.player = player
    self.pj = pj
    self. otroPlayer = otroPlayer
    self.personaje = player[pj]
    
    if player == player1:
      self.numPlayer = 1
    else:
      self.numPlayer = 2



  
  


  
      
class habilidad:
  def __init__(self, tipo, nombre, costeSP, efectoExtra, descripcion, textoAlUsarse):
    
    self.tipo = tipo
    self.nombre = nombre
    self.costeSP = costeSP
    
    self.extra = efectoExtra # EL EFECTO EXTRA TIENE DISTINTOS USOS DEPENDIENDO DE CADA TIPO DE HABILIDAD
    
    self.descripcion = descripcion
    self.textoEjecucion = textoAlUsarse

  
  def curar(self, player, pj, objetivo): 
    if self.extra == "mucho":
      player[objetivo].vida += 20
      
    elif self.extra == "poco":
      player[objetivo].vida += 10
      
    elif self.extra == "estados":
      player[objetivo].estado = None
      player[objetivo].duraEstado = 0
      
    if player[pj].vida > player[pj].vidaMaxima:
      player[pj].vida = player[pj].vidaMaxima




  
  def dps(self, player, otroPlayer, pj, objetivo, jugador):


    if otroPlayer.player[objetivo].estado == self.extra:
      jugador.ataqueCritico(objetivo, pj)

    else:
      jugador.ataqueComun(objetivo, pj)


    
    
    




  
  def gamble(self, player, pj, otroPlayer, objetivo, jugador):
    
    jugador.ataqueComun(objetivo, pj)
    
    if random.choice(chance) == 2:
      otroPlayer.player[objetivo].estado = self.extra
      otroPlayer.player[objetivo].duraEstados = 3
      
      print("Has {0} a {1}.".format(otroPlayer.player[objetivo].estado, otroPlayer.player[objetivo]))




  
  def control(self, player, pj, otroPlayer, objetivo):
       
    if random.choice(chance) == 1:
      otroPlayer.player[objetivo].estado = self.extra
      otroPlayer.player[objetivo].duraEstados = 3
      
      print("Has {0} a {1}.".format(otroPlayer.player[objetivo].estado, otroPlayer.player[objetivo]))
      
    else:
      print("No ha {0}.".format(self.extra))
    



    
  def support(self, player, pj, objetivo):
    
    player[objetivo].bufo.append(self.extra)
    player[objetivo].duraBufo.append(3)



  
  def suppornt(self, player, pj, otroPlayer, objetivo):
  # FALTA HACER
    otroPlayer.player[objetivo].bufo.append(self.extra)
    otroPlayer.player[objetivo].duraBufo.append(3)



  def usarHabilidad(self, player, otroPlayer, pj, objetivo, jugador):

    player[pj].estamina -= self.costeSP
    
    if self.tipo == "curar":

      if player[objetivo].muerto == True:
        self.curar(player, pj, objetivo)
      else:
        print("El objetivo ya está muerto. Intente ora vez.")
        objetivo = seleccionObjetivo(player)
        self.usarHabilidad(player, otroPlayer, pj, objetivo)

    else:
      if otroPlayer.player[objetivo].muerto == False:
      
        if self.tipo == "dps":
          self.dps(player, otroPlayer, pj, objetivo, jugador)
          
        elif self.tipo == "control":
          self.control(player, pj, otroPlayer, objetivo)
          
        elif self.tipo == "support":
          self.support(player, pj, objetivo)
          
        elif self.tipo == "suppornt":
          self.suppornt(player, pj, otroPlayer, objetivo)
          
    
        elif self.tipo == "gamble":
          self.gamble(player, pj, otroPlayer, objetivo, jugador)

      else:
        print("El objetivo ya está muerto. Intente ora vez.")
        objetivo = seleccionObjetivo(player)
        self.usarHabilidad(player, otroPlayer, pj, objetivo)

    print("")
    print(self.textoEjecucion)
    sleep(1)



#------------------------------ HABILIDADES CREADAS ------------------------------#

#navajazoVeneno = habilidad("gamble", "Navajazo envenenado", 5, "envenenado", "", "Realizas un corte con tu navaja envenenada al enemigo.")

puñetazo = habilidad("dps", "Puñetazo", 5, "congelado", "El usuario da un puñetazo especialmente fuerte contra objetivos congelados.", "Diste un puñetazo al objetivo.")

santaCura = habilidad("curar", "Santa cura", 10, "mucho", "El usuario utiliza el poder divino para curar a un aliado.", "Usaste el poder divino para curar a tu aliado.")

botellazo = habilidad("dps", "Botellazo", 5, "quemado", "El usuario lanza una botella con alcohol al oponente.", "Le lanzaste una botella al oponente.")

cocinaAmorosa = habilidad("dps", "Cocina amorosa", 5, "enamorado", "el usuario cocina un pastel que hace daño al enemigo, especialmente si está enamorado.", "Le diste un pastel tan dulce al enemigo que le hiciste daño.")

simpeo = habilidad("control", "Simpeo", 10, "enamorado", "El usuario utiliza palabras dulces para enamorar al objetivo.", "Le dijiste palabras dulces al oponente para enamorarlo.")





#----------------------------- CLASE CHARACTER ------------------------#


class character:
  estado = None
  duraEstado = 0
  muerto = False
  oneMore = 0
  pasado = False
  inmovil = False
  bufo = []
  duraBufo = []
  
  def __init__(self, nom, hp, sp, atq, crit, defe, fraseAtq, skillOne, skillTwo, skillThree):
    self.nombre = nom
    self.vidaMaxima = hp
    self.vida = hp
    self.estamina = sp

    self.fraseAtaque = fraseAtq

    # LAS STATS DE BASE DE USAN PARA RESETEARLAS DESPUES DE QUE SE ACABE UN BUFO
    self.ataqueBase = atq
    self.criticoBase = crit
    self.defensaBase = defe
    
    self.ataque = atq
    self.critico = crit
    self.defensa = defe

    self.skillOne = skillOne
    self.skillTwo = skillTwo
    self.skillThree = skillThree


  

  def bufarse(self): #Concepto de bufos múltiples
    for ele in self.bufo:
      
      if self.duraBufo[self.bufo.index(ele)] > 0:
        
        if ele == "ataque+":
          self.ataque = self.ataqueBase * 2
        elif ele == "defensa+":
          self.defensa = self.defensaBase * 2
        elif ele == "crit+":
          self.critico.append(2)
          del self.critico[1]
          
        elif ele == "todo+":
          self.ataque = self.ataqueBase * 2
          self.defensa = self.defensaBase * 2
          self.critico = self.criticoBase
          
        else:
          self.ataque = self.ataqueBase
          self.critico = self.criticoBase
          self.defensa = self.defensaBase
        
        if self.bufo == "ataque-":
          self.ataque = self.ataqueBase / 2
        elif self.bufo == "defensa-":
          self.defensa = self.defensaBase / 2
        elif self.bufo == "crit-":
          self.critico.append(0)
          del self.critico[2]
          
        elif self.bufo == "todo-":
          self.ataque = self.ataqueBase / 2
          self.defensa = self.defensaBase / 2
          self.critico = self.criticoBase
          
        else:
          self.ataque = self.ataqueBase
          self.critico = self.criticoBase
          self.defensa = self.defensaBase
          
        self.duraBufo[self.bufo.index(ele)] -= 1






#----------------------------------------- PERSONAJES CREADOS ----------------------#





frasesPuszko = [
  "Ayyy...",
  "Re puto.",
  "Qué puto.",
  "Nashe..."
]

puszko = character("Puszko", 200, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, frasesPuszko, puñetazo, santaCura, botellazo)

frasesMatis = [
  "Callate, zoofílico.",
  "Chigar, sexo, follar, coger, penetrar...",
  "Acceso carnal.",
  "Me gusta tu abuela.",
  "No ilusiones.",
  "¿Coito?"
]

matis = character("Matiss", 200, 200, 10, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 6, frasesMatis, puñetazo, santaCura, botellazo)

frasesHilliel = [
  "Ayyy...",
  "Re puto.",
  "Te hago mierda, wachin.",
  "Nashe..."
]

hilliel = character("Hilliel", 250, 50, 30, [0, 0, 1, 1, 1, 1, 1, 1, 2, 2], 20, frasesHilliel, puñetazo, santaCura, botellazo)

frasesMilli = [
  "Ilusiones, no me fallen ahora.",
  "Y por eso, niños, coman toda la tierra que puedan mientras son jóvenes.",
  "Tu culo es muy débil.",
  "Somos jesús."
]

milli = character("Millicay", 200, 200, 10, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 6, frasesMilli, puñetazo, santaCura, botellazo)

frasesFanty = [
  "Ayyy...",
  "Re puto.",
  "Qué puto.",
  "Dios...",
  "¡La concha de tu madre!"
]

fanty = character("Fantrack", 200, 100, 30, [0, 1, 1, 1, 1, 1, 2, 2, 2, 2], 6, frasesFanty, puñetazo, santaCura, botellazo)

frasesMonino = [
  "¡La concha de tu madre!",
  "Re peruano."
]


monino = character("Monino", 200, 100, 40, [0, 1, 1, 1, 1, 2, 2, 2, 2, 2], 6, frasesMonino, puñetazo, santaCura, botellazo)

frasesRow = [
  "La ley es subjetivo.",
  "Agujero que veo tapo."
]


row = character("Row", 200, 100, 30, [0, 1, 1, 1, 1, 2, 2, 2, 2, 2], 6, frasesRow, puñetazo, santaCura, botellazo)


frasesNico = [
  "Ayyy...",
  "Re puto.",
  "Qué puto.",
  "Nashe...",
  "Nico muerte in the house"
]

nico = character("Nico", 200, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, frasesNico, puñetazo, santaCura, botellazo)

frasesMoreira = [
  "La puta madre, los voy a banear a todos.",
  "Pido perdón con antelación, pero hoy os voy a dar por culo.",
  "Me caen mal todos.",
  "Apártense, me la voy a follar."
]

moreira = character("Moreira", 200, 100, 20, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 10, frasesMoreira, puñetazo, santaCura, botellazo)

frasesAlbanese = [
  "Llamen a Yayu que me lo culeo."
]

albanese = character("Albanese", 200, 100, 10, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 6, frasesAlbanese, puñetazo, santaCura, botellazo)

frasesTrapo = [
  "Chúpenme el pico."
]

trapo = character("Trapo", 200, 100, 10, [0, 1, 1, 1, 1, 1, 1, 1, 2, 2], 6, frasesTrapo, puñetazo, santaCura, cocinaAmorosa)




personaje = [puszko, matis, hilliel, milli, fanty, row, nico, moreira, albanese, trapo]


# -------------------------------------------------------------------------
# --------------------------- VARIABLES VITALES ---------------------------
# -------------------------------------------------------------------------


escape = [0, 1, 1, 1, 1, 1, 1, 2, 2]
pases = 0
chance = [1, 1, 2]




#Personajes de los players
player1 = {}
player2 = {}





gameOver = False

# -------------------------------------------------------------------------
# --------------------------- Seleccion Personajes ---------------------------
# -------------------------------------------------------------------------
        
#Selección de personajes.
b = 1

def seleccionObjetivo(playerObjetivo):
    objetivo = int(input("¿A quién desea atacar? [1] [2] [3] [4]: "))

    if objetivo not in (0, 1, 2, 3, 4):
      print("Objetivo incorrecto. Intente otra vez.")
      seleccionObjetivo(playerObjetivo)

    return(objetivo)


def printearJugador(player):
  print("")
  print("Jugador {0}".format(player.numPlayer))
  print("")




def printearPersonajesDisponibles():

  indice = 0
  numPrinteo = indice + 1
  indiceMax = len(personaje) - 1
  
  while indice <= indiceMax:
    
    print("{0}. {1}:".format(numPrinteo, personaje[indice].nombre))
    
    indice += 1
    numPrinteo = indice + 1




def seleccionPersonajes(jugador):
  #Propósito: Elegir personajes para los jugadores.
  #Precondición: al elegir el personaje el usuario debe ingresar un número entero.
  global b
  
  while b != 5:
    
    printearPersonajesDisponibles()
    printearJugador(jugador)

    
    #"a" debe coincidir con el largo de la lista (restandole uno)
    a = int(input("Elija el personaje en posición {0}: ".format(b))) - 1 

    if ( (a + 1) == 99 ): #99 comando ADMIN

      jugador.player[1] = personaje.pop(0)
      jugador.player[2] = personaje.pop(0)
      jugador.player[3] = personaje.pop(0)
      jugador.player[4] = personaje.pop(0)

      b = 4

#    elif (a == -1):
#      personajeRandom = random.choice(len(personaje))
#      player[b] = personaje.pop(personajeRandom)
      
    
    elif ( a < len(personaje) ):
      
      jugador.player[b] = personaje.pop(a)
      
    else:
      print(a + 1, "no es válido.")
      sleep(1)
      
      os.system('clear')
      seleccionPersonajes(jugador)
      
    b += 1
    os.system('clear')
  b=1

# ------------------------------------------------------------------------- #
# --------------------------------- ATAQUE -------------------------------- #
# ------------------------------------------------------------------------- #






def printPersonajeQueAtaca(player, pj): 
  if player == player1:
    print("Jugador 1: {0}".format(player[pj].nombre))
    
  else:
    print("Jugador 2: {0}".format(player[pj].nombre))











def printerVida(jugador):
  #Propósito: Imprimir la posición, el nombre, la vida y el estado de los characters de los jugadores. 
  for elem in jugador.player:
    
    if jugador.player[elem].muerto == False:

      if jugador.player[elem].estado != None:
        print("{0}. {1} HP: {2} SP: {3}  ({4})". format(elem, jugador.player[elem].nombre, jugador.player[elem].vida, jugador.player[elem].estamina, jugador.player[elem].estado))
      else:
        print("{0}. {1} HP: {2} SP: {3}". format(elem, jugador.player[elem].nombre, jugador.player[elem].vida, jugador.player[elem].estamina))
      
      if len(jugador.player[elem].bufo) > 0:
        print(jugador.player[elem].bufo)

    else:
      
      print("{0}. {1}: muerto". format(elem, jugador.player[elem].nombre))
  print("")


# -------------------------------------------------------------------------
# ------------------------------- WIN FUNCTION ----------------------------
# -------------------------------------------------------------------------



def comprobacionGanado(player, muertos):
  for elem in player.keys():
    
    if player[elem].muerto == False:
      
      if player[elem].vida <= 0:
        player[elem].muerto = True
        sleep(0.5)
        print("¡{0} ha muerto!".format(player[elem].nombre))
        print("")
        sleep(1)
        player.cantidadMuertos += 1
      
  if player.cantidadMuertos >= 4:
    print("¡Jugador {0} ha ganado!".format(jugador))
    sleep(1)
    quit()




def comprobarGanar():
  global gameOver
  
  for elem in jugadorUno.player.keys():
    
    if jugadorUno.player[elem].muerto == False:
      
      if jugadorUno.player[elem].vida <= 0:
        
        jugadorUno.player[elem].muerto = True
        jugadorUno.player[elem].inmovil = True
        sleep(0.5)
        print("¡{0} ha muerto!".format(jugadorUno.player[elem].nombre))
        print("")
        sleep(1)
        jugadorUno.cantidadMuertos += 1
      
  if jugadorUno.cantidadMuertos >= 4:
      print("¡Jugador 2 ha ganado!")
      sleep(1)
      gameOver = True

  
  for elem in jugadorUno.player.keys():
    
    if jugadorDos.player[elem].muerto == False:
      
      if jugadorDos.player[elem].vida <= 0:
        
        jugadorDos.player[elem].muerto = True
        jugadorDos.player[elem].inmovil = True
        
        sleep(0.5)
        print("¡{0} ha muerto!".format(jugadorDos.player[elem].nombre))
        print("")
        sleep(1)
        
        jugadorDos.cantidadMuertos += 1

  if jugadorDos.cantidadMuertos >= 4:
    print("¡Jugador 1 ha ganado!")
    sleep(1)
    gameOver = True

    

def printerVidaJugadores():
  #Propósito: Imprimir la posición, el nombre, la vida y el estado de los characters de los jugadores. 
  os.system('clear')
  
  print("")
  print("JUGADOR 1")
  printerVida(jugadorUno)

  
  print("")
  print("JUGADOR 2")
  printerVida(jugadorDos)
  





def comprobarEstados(player):
  for personaje in player:
    if player[personaje].estado == "quemado":
      #hacer los efectos de quemado
      player[personaje].duraEstado -= 1
      
    elif player[personaje].estado == "congelado":
      player[personaje].inmovil = True
      player[personaje].duraEstado -= 1
      
    elif player[personaje].estado == "stuneado":
      player[personaje].inmovil = True
      player[personaje].duraEstado -= 1
      
    if player[personaje].duraEstado <= 0:
      if player[personaje].muerto == True:
        player[personaje].inmovil = True
        
      else:
        player[personaje].estado = None
        player[personaje].inmovil = False

def comprobarPasado():
  for personaje in player1:
    player1[personaje].pasado = False
  for personaje in player2:
    player2[personaje].pasado = False

def comprobarBufos(player):
  for personaje in player:
    player[personaje].bufarse()


def acto(): #conjunto de turnos de cada personaje de cada jugador
  comprobarEstados(player1)
  comprobarEstados(player2)
  comprobarPasado()
  comprobarBufos(player1)
  comprobarBufos(player2)

  turnosPorPasar = 1

  while turnosPorPasar < 5:

    if gameOver == False:

      jugadorUno.turno(turnosPorPasar)
      
      comprobarGanar()
    
    if gameOver == False:

      jugadorDos.turno(turnosPorPasar)
      
      comprobarGanar()

    turnosPorPasar += 1
    


  if gameOver == False:
    acto()
      





seleccionPersonajes(jugadorUno)
seleccionPersonajes(jugadorDos)

acto()