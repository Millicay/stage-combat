import os
from time import sleep
import random
import sqlite3
import pygame, sys

###################
## Inicio sqlite ##
###################

conexion=sqlite3.connect("bd/bdstagecombat.db")
personaje=conexion.execute("SELECT * FROM infoPersonaje")

background=conexion.execute("SELECT imagen FROM infoBackground WHERE idbackground=1")
for fila in background:
     fondobd=fila
     fondonormal= ''.join(fondobd)
print(fondonormal)

###################
## Inicio pygame ##
###################

pygame.init()

clock = pygame.time.Clock()

size = 1280, 720

ventana = pygame.display.set_mode(size)

pygame.display.set_caption("StageCombat")

fondo = pygame.image.load(fondonormal).convert_alpha()
fondo1 = pygame.transform.scale(fondo, (1280, 720))


# Boton Jugar

jugarBoton = pygame.image.load("images/Jugar.png").convert_alpha()
jugarBoton1 = pygame.transform.scale(jugarBoton, (295, 100))
jugarBoton_rect = jugarBoton1.get_rect(topleft = (290,306))
jugarHover = pygame.image.load("images/JugarHover.png").convert_alpha()
jugarHover1 = pygame.transform.scale(jugarHover, (470, 270))

# Boton Opciones

opcionesBoton = pygame.image.load("images/Opciones.png").convert_alpha()
opcionesBoton1 = pygame.transform.scale(opcionesBoton, (295, 100))
opcionesBoton_rect = opcionesBoton1.get_rect(topleft = (705,307))
opcionesHover = pygame.image.load("images/OpcionesHover.png").convert_alpha()
opcionesHover1 = pygame.transform.scale(opcionesHover, (470, 270))


default = pygame.image.load("images/Default.png").convert_alpha()
default1 = pygame.transform.scale(default, (1280, 720))


####################
### Inicio juego ###
####################

pantallaActual = "principal"

def menu():
            global pantallaActual
            if pantallaActual == "principal":
                ventana.blit(fondo1, (0,0))
                ventana.blit(jugarBoton1, jugarBoton_rect)
                ventana.blit(opcionesBoton1, opcionesBoton_rect)

                mouse_pos = pygame.mouse.get_pos()
                
                if jugarBoton_rect.collidepoint(mouse_pos):
                    background=conexion.execute("SELECT imagen FROM infoBackground WHERE idbackground=2")
                    for fila in background:
                         print(fila)
                    ventana.blit(fondo1, (0,0))
                    ventana.blit(jugarHover1, (200,240))
                    if event.type == pygame.MOUSEBUTTONUP:
                        pantallaActual = "jugar"
                else:
                    jugarBoton1

                if opcionesBoton_rect.collidepoint(mouse_pos):
                    ventana.blit(fondo1, (0,0))
                    ventana.blit(opcionesHover1, (600,240))
                    if event.type == pygame.MOUSEBUTTONUP:
                        pantallaActual = "opciones"
                else:
                    opcionesBoton1

            if pantallaActual == "jugar":
                 ventana.blit(default, (0,0))

            if pantallaActual == "opciones":
                 ventana.blit(default, (0,0))
     
     

run=True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: run = False
        menu()
        pygame.display.update()
    clock.tick(60)




conexion.close

pygame.quit()